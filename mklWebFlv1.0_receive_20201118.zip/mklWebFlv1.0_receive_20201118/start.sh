nohup node app.js >/dev/null 2>&1 &
